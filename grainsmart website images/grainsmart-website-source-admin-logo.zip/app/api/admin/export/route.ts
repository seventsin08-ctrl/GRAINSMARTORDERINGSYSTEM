import { env } from "cloudflare:workers";
import { NextResponse } from "next/server";
import { getAdminSession } from "../session";

const field = (value: unknown) => `"${String(value ?? "").replaceAll('"', '""')}"`;
const csv = (rows: unknown[][]) => rows.map(row => row.map(field).join(",")).join("\r\n");
const dateValid = (value: string) => /^\d{4}-\d{2}-\d{2}$/.test(value) && !Number.isNaN(Date.parse(`${value}T00:00:00Z`));
const peso = (value: number) => Number(value || 0).toFixed(2);
const timeInManila = (value: string | null) => value ? new Date(value).toLocaleString("en-PH", { timeZone: "Asia/Manila", hour12: false }) : "";

export async function GET(request: Request) {
  const session = await getAdminSession();
  if (!session) return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  if (!env.DB) return NextResponse.json({ error: "The report database is unavailable." }, { status: 503 });

  const params = new URL(request.url).searchParams;
  const type = params.get("type");
  const start = params.get("start") || new Date().toISOString().slice(0, 10);
  const end = params.get("end") || start;
  if (!dateValid(start) || !dateValid(end) || start > end) return NextResponse.json({ error: "Choose a valid report date range." }, { status: 400 });

  let contents: string;
  let name: string;
  if (type === "sales") {
    if (!(session.role === "Owner/Admin" || session.permissions.includes("reports"))) return NextResponse.json({ error: "Sales report access is not enabled for this account." }, { status: 403 });
    const orders = await env.DB.prepare("SELECT number,created_at,items,total,method,payment_method,paid,status FROM orders WHERE date(created_at,'+8 hours') BETWEEN ? AND ? ORDER BY created_at").bind(start, end).all<any>();
    const monthly: Record<string, { revenue: number; orders: number }> = {};
    const daily: Record<string, { revenue: number; orders: number }> = {};
    const paid = orders.results.filter((order: any) => order.paid === 1);
    const revenue = paid.reduce((sum: number, order: any) => sum + Number(order.total || 0), 0);
    for (const order of paid) {
      const day = new Date(order.created_at).toLocaleDateString("en-CA", { timeZone: "Asia/Manila" });
      const month = day.slice(0, 7);
      daily[day] ??= { revenue: 0, orders: 0 };
      daily[day].revenue += Number(order.total || 0);
      daily[day].orders++;
      monthly[month] ??= { revenue: 0, orders: 0 };
      monthly[month].revenue += Number(order.total || 0);
      monthly[month].orders++;
    }
    const rows: unknown[][] = [
      ["GrainSmart sales export", "", "", "", "", "", "", "", "", "", "", ""],
      ["Period start", start], ["Period end", end],
      ["Record type", "Date", "Month", "Order number", "Time (Asia/Manila)", "Order method", "Payment method", "Paid", "Status", "Items", "Quantity", "Amount (PHP)"],
      ["SUMMARY", start, "", "", "", "", "", "", "", "Paid revenue", paid.length, peso(revenue)],
      ["SUMMARY", start, "", "", "", "", "", "", "", "Payment due", orders.results.filter((order: any) => order.paid === 0 && order.status !== "cancelled").length, ""],
      ["SUMMARY", start, "", "", "", "", "", "", "", "Cancelled orders", orders.results.filter((order: any) => order.status === "cancelled").length, ""],
    ];
    for (const [month, values] of Object.entries(monthly).sort(([a], [b]) => a.localeCompare(b))) rows.push(["MONTHLY REVENUE", "", month, "", "", "", "", "", "", "Paid orders", values.orders, peso(values.revenue)]);
    for (const [day, values] of Object.entries(daily).sort(([a], [b]) => a.localeCompare(b))) rows.push(["DAILY SALES", day, day.slice(0, 7), "", "", "", "", "", "", "Paid orders", values.orders, peso(values.revenue)]);
    for (const order of orders.results) {
      const items = JSON.parse(order.items || "[]");
      const itemText = items.map((item: any) => `${item.qty} x ${item.name}`).join("; ");
      const quantity = items.reduce((sum: number, item: any) => sum + Number(item.qty || 0), 0);
      const day = new Date(order.created_at).toLocaleDateString("en-CA", { timeZone: "Asia/Manila" });
      rows.push(["ORDER", day, day.slice(0, 7), order.number, timeInManila(order.created_at), order.method, order.payment_method, order.paid ? "Paid" : "Unpaid", order.status, itemText, quantity, peso(order.total)]);
      for (const item of items) rows.push(["ITEM", day, day.slice(0, 7), order.number, timeInManila(order.created_at), order.method, order.payment_method, order.paid ? "Paid" : "Unpaid", order.status, item.name, item.qty, peso(Number(item.unit || 0) * Number(item.qty || 0))]);
    }
    contents = csv(rows);
    name = `grainsmart-sales-${start}-to-${end}.csv`;
  } else if (type === "attendance") {
    if (!(session.role === "Owner/Admin" || session.permissions.includes("attendance_manage"))) return NextResponse.json({ error: "Only an admin or attendance manager can export staff attendance." }, { status: 403 });
    const attendance = await env.DB.prepare("SELECT username,clock_in,clock_out FROM attendance WHERE date(clock_in,'+8 hours') BETWEEN ? AND ? ORDER BY clock_in").bind(start, end).all<any>();
    const rows: unknown[][] = [["Staff attendance export"], ["Period start", start], ["Period end", end], ["Staff username", "Clock in (Asia/Manila)", "Clock out (Asia/Manila)", "Elapsed hours", "Shift status"]];
    for (const entry of attendance.results) {
      const elapsed = entry.clock_out ? Math.max(0, (Date.parse(entry.clock_out) - Date.parse(entry.clock_in)) / 3600000) : null;
      rows.push([entry.username, timeInManila(entry.clock_in), timeInManila(entry.clock_out), elapsed === null ? "" : elapsed.toFixed(2), entry.clock_out ? "Complete" : "Still clocked in"]);
    }
    contents = csv(rows);
    name = `grainsmart-attendance-${start}-to-${end}.csv`;
  } else return NextResponse.json({ error: "Choose a sales or attendance export." }, { status: 400 });

  return new Response(`\uFEFF${contents}`, { headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": `attachment; filename="${name}"`, "Cache-Control": "no-store" } });
}
