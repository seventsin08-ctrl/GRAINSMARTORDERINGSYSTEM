import { integer, real, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";
import { sql } from "drizzle-orm";

export const categories = sqliteTable("categories", {
  id: text("id").primaryKey(), name: text("name").notNull(), sort: integer("sort").notNull().default(0), active: integer("active").notNull().default(1),
});
export const products = sqliteTable("products", {
  id: text("id").primaryKey(), categoryId: text("category_id").notNull(), name: text("name").notNull(), description: text("description").notNull().default(""), price: real("price").notNull(), image: text("image").notNull().default(""), available: integer("available").notNull().default(1), featured: integer("featured").notNull().default(0), customization: integer("customization").notNull().default(0),trackStock:integer("track_stock").notNull().default(0),stockQty:integer("stock_qty").notNull().default(0),stockUnit:text("stock_unit").notNull().default("each"),lowThreshold:integer("low_threshold").notNull().default(0),
});
export const orders = sqliteTable("orders", {
  id: text("id").primaryKey(), number: text("number").notNull(), createdAt: text("created_at").notNull(), items: text("items").notNull(), total: real("total").notNull(), method: text("method").notNull(), details: text("details").notNull(), paymentMethod: text("payment_method").notNull(), paid: integer("paid").notNull().default(0), status: text("status").notNull().default("new"), loyaltyCardId:text("loyalty_card_id"), rewardProductId:text("reward_product_id"), rewardApplied:integer("reward_applied").notNull().default(0), rewardPoints:integer("reward_points").notNull().default(0),
});
export const settings = sqliteTable("settings", { key: text("key").primaryKey(), value: text("value").notNull() });
export const staff = sqliteTable("staff", { id: text("id").primaryKey(), username: text("username").notNull().unique(), passwordHash: text("password_hash").notNull(), role: text("role").notNull(), permissions: text("permissions").notNull(), active: integer("active").notNull().default(1) });
export const loginAttempts = sqliteTable("login_attempts", { id: integer("id").primaryKey({ autoIncrement: true }), ipHash: text("ip_hash").notNull(), attemptedAt: integer("attempted_at").notNull(), succeeded: integer("succeeded").notNull().default(0) });
export const attendance = sqliteTable("attendance", { id: text("id").primaryKey(), username: text("username").notNull(), clockIn: text("clock_in").notNull(), clockOut: text("clock_out") }, t=>[uniqueIndex("attendance_one_active").on(t.username).where(sql`${t.clockOut} IS NULL`)]);
export const schedules = sqliteTable("schedules", { id: text("id").primaryKey(), username: text("username").notNull(), shiftDate: text("shift_date").notNull(), startTime: text("start_time").notNull(), endTime: text("end_time").notNull(), note: text("note").notNull().default("") });
export const loyaltyCards = sqliteTable("loyalty_cards", { id:text("id").primaryKey(),codeHash:text("code_hash").notNull().unique(),suffix:text("suffix").notNull(),points:integer("points").notNull().default(0),active:integer("active").notNull().default(1),createdAt:text("created_at").notNull() });
export const loyaltyEvents = sqliteTable("loyalty_events", { id:text("id").primaryKey(),cardId:text("card_id").notNull(),orderId:text("order_id"),kind:text("kind").notNull(),amount:integer("amount").notNull(),reason:text("reason").notNull().default(""),actor:text("actor").notNull().default("system"),createdAt:text("created_at").notNull() },t=>[uniqueIndex("loyalty_card_order_kind").on(t.cardId,t.orderId,t.kind)]);
export const inventoryMovements=sqliteTable("inventory_movements",{id:text("id").primaryKey(),productId:text("product_id").notNull(),orderId:text("order_id"),kind:text("kind").notNull(),qtyDelta:integer("qty_delta").notNull(),reason:text("reason").notNull(),actor:text("actor").notNull(),createdAt:text("created_at").notNull()},t=>[uniqueIndex("inventory_product_order_kind").on(t.productId,t.orderId,t.kind)]);


